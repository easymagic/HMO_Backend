<?php 

 class SUB_Controller extends CI_Controller{
   


    function __construct(){
    	
    	parent::__construct();

    	controller($this); //hold a reference to the controller.

    }
   

 }