<?php 
 
 //load usecases
 init_usecases('admin');


//get_company_access_type

 function admin_company_badge($company_id){
  $resp = __action('entity_get_where','company',array("id"=>$company_id));
  return $resp[0]->name;
 }
 add_listener('company_badge','admin_company_badge'); 

 function admin_menu($menu){
 
   $r = $menu;
   $account = session('admin_account');

   $access = $account->access;

   $excluded_types = array('doctor','patient');   


    foreach ($access['company'] as $k=>$v){

      if (!in_array($account->type, $excluded_types)){

        if (!isset($r['Add Company']))$r['Add Company']=array('icon'=>'fa fa-building','items'=>array());

        $r['Add Company']['items'][] = array(ucfirst($v),"company/add_$v","fa fa-user");


     // $r = array_merge($r,array(  ));     

      }

    }

    


    foreach ($access['users'] as $k=>$v){
  
     if (!in_array($account->type, $excluded_types)){
      if (!isset($r['Add User']))$r['Add User']=array('icon'=>'fa fa-users','items'=>array());
      $r['Add User']['items'][] = array(ucfirst($v),"admin/add_$v","fa fa-user");
      // $r = array_merge($r,array(  ));     
     }
     
    }


    

    foreach ($access['company'] as $k=>$v){

      if (!in_array($account->type, $excluded_types)){
        if (!isset($r['View Companies']))$r['View Companies']=array('icon'=>'fa fa-eye','items'=>array());
        $r['View Companies']['items'][] = array(ucfirst($v),"company/$v","fa fa-user");
       // $r = array_merge($r,array( ));     
      }
     
    }



   
   // if ($role == 'admin'){
    foreach ($access['users'] as $k=>$v){

     if (!in_array($account->type, $excluded_types)){

      if (!isset($r['View Users']))$r['View Users']=array('icon'=>'fa fa-eye','items'=>array());
      $r['View Users']['items'][] = array(ucfirst($v),"admin/$v","fa fa-user");
      // $r = array_merge($r,array());     
     }
      
    }


    

    foreach ($access['features'] as $k=>$v){


     if (!in_array($account->type, $excluded_types)){

      if (!isset($r['Store']))$r['Store']=array('icon'=>'fa fa-cogs','items'=>array());

      $r['Store']['items'][] = array($k,$v,"fa fa-user");
      // $r = array_merge($r,array());     
     }
      
    }

   
   if (isset($access[$account->type])){
    foreach ($access[$account->type] as $k=>$v){

      if (!isset($r['Extras']))$r['Extras']=array('icon'=>'fa  fa-chevron-circle-down','items'=>array());

     // if (!in_array($account->type, $excluded_types)){
      $r['Extras']['items'][] = array($k,$v,"fa fa-user");
      // $r = array_merge($r,array());     
     // }
      
    }
   } 


   // }

   // $r = array_merge($r,array(array("Admin Acct.","admin/profile")));
   // $r = array_merge($r,array(array("Change Pwd.","admin/change_password")));

   // print_r($r);
   return $r;
 }
 add_listener('admin_menu','admin_menu');


 function admin_types(){

  $staff = array();
  $patient = array('Visitations'=>'visitation/view');
  $doctor = array('Log Visitation'=>'visitation/log');


  $config = array();
  
  $config['hmo_guru'] = array('company'=>array('hmo'),'users'=>array('staff'),
   'features'=>array(),
   'patient'=>array(),
   'doctor'=>$doctor
  );
  
  $config['hmo'] = array('company'=>array('hospital'),'users'=>array('staff','patient'),
    'features'=>array(),
    'patient'=>$patient,
    'doctor'=>$doctor
  );

  $config['hospital'] = array('company'=>array(),'users'=>array('staff','doctor','patient'),
    'features'=>array(
      'Drugs'=>'payable/drugs',
      'Services'=>'payable/services'
    ),
    'patient'=>$patient,
    'doctor'=>$doctor
  );

  // $config['doctor'] = array(''=>'visitations/view');



  return $config;

 }
 add_listener('admin_types','admin_types');

 function get_company_access_type($company_id){
  
  $resp = __action('entity_get_where','company',array('id'=>$company_id));
  $resp = $resp[0];
  
  $admin_types = __filter('admin_types');

  return $admin_types[$resp->type];

 }
 add_listener('get_company_access_type','get_company_access_type');

 function admin_get_region_companies($type='',$vl=''){
  
  $account = session('admin_account');
  
  $company_id = $account->company_id;

  __action('entity_where',array("created_by"=>$company_id,"type"=>$type));
  $items = __action('entity_get','company');
  
  // print_r($items);
  // print_r(array("created_by"=>$company_id,"type"=>$type));
  
  start_buffer();
  echo '<select data-value="' . $vl . '" name="post_data[company_id2]" class="form-control" required>'; 
  foreach ($items as $k=>$v){

    echo '<option value="' . $v->id . '">' . $v->name . '</option>';

  } 
  echo '</select>';
  return get_buffer();

 }
 add_listener('get_dropdown_companies','admin_get_region_companies');


 function admin_login(){

  save_history();
  
  if (!empty(session('admin_account'))){
    // $type = session('admin_account')->type;
    redirect('admin/staff');
  }
  // print_r(_db());	
  start_buffer();
  include('template/login.php');
  return __filter('default_theme',get_buffer());
 }
 add_listener('nav_admin_login','admin_login');
 add_listener('nav_home_index_new','admin_login');
 add_listener('nav_admin_index','admin_login');

 function admin_welcome(){
  $user_obj = session('admin_account');

  return __filter('nav_admin_panel','<b>Welcome ,<i>Administrator.</i></b>');

 }
 add_listener('nav_admin_welcome','admin_welcome');

 
 function admin_title(){
  
  return '<b>HMO GURU</b>';

 }
 add_listener('admin_title','admin_title');

 
 function admin_logout_text(){
   return 'Log-Out';
 }
 add_listener('admin_logout_text','admin_logout_text');


 function admin_logout_url(){
   return BASE_URL . 'actions/launch/admin/logout';
 }
 add_listener('admin_logout_url','admin_logout_url');


 function admin_panel($content=''){
 	// echo 'Called.';
  if (empty(session('admin_account'))){
    redirect('home/index_new');
  }	
  start_buffer();
  include('template/panel.php');
  return __filter('default_theme',get_buffer());
 }
 add_listener('nav_admin_panel','admin_panel');


// function admin_logout(){
//  session('admin_account','__unset__');
//  log_success('Just logged out.');
// } 
// add_listener('uc_admin_logout','admin_logout');


 //pages
 function entity_users($type='',$cid=''){

  save_history();
  session('entity_type',$type);

  $company_id = session('admin_account')->company_id;
  
  if (!empty($cid)){
    $company_id = $cid;
  }

  __action('entity_where','company_id',$company_id);
  __action('entity_where','type',$type);
  __action('launch_usecase',array('admin','all'));
  $users = response('data');

  start_buffer();
  include('template/users.php');	
  return __filter('nav_admin_panel',get_buffer());
 
 }
 add_listener('nav_entity_users','entity_users');

 function admin_staff($id=''){
  return __action('nav_entity_users','staff',$id);
 }
 add_listener('nav_admin_staff','admin_staff');

 function admin_patient($id=''){
  return __action('nav_entity_users','patient',$id);
 }
 add_listener('nav_admin_patient','admin_patient');

 function admin_doctor(){
  return __action('nav_entity_users','doctor');
 }
 add_listener('nav_admin_doctor','admin_doctor');




function admin_edit($id=''){
 $item = __action('entity_get_where','user',array("id"=>$id));
 $item = $item[0];

 // __action('entity_where','parent_id','0');
 __action('launch_usecase',array('table','list'));
 $tables = response('data');
 // print_r($tables);
 // print_r($item);
 start_buffer();
 include('template/edit.php');
 return __filter('nav_admin_panel',get_buffer());
}
add_listener('nav_admin_edit','admin_edit');



function admin_profile(){

 save_history(); 
 $id = session('admin_account')->id;  
 $item = __action('entity_get_where','user',array("id"=>$id));
 $item = $item[0];
 // print_r($item);
 start_buffer();
 include('template/profile.php');
 return __filter('nav_admin_panel',get_buffer());

}
add_listener('nav_admin_profile','admin_profile');


function admin_change_password(){
  save_history();
  if (!empty(session('admin_account'))){
    $id = session('admin_account')->id;
  }
  start_buffer();
  include('template/change_password.php');
  return __filter('nav_admin_panel',get_buffer());

}
add_listener('nav_admin_change_password','admin_change_password');



function entity_add_user($type=''){
 save_history(); 
 start_buffer();
 session('entity_type',$type);
 include('template/add_user.php');
 return __filter('nav_admin_panel',get_buffer());
}
add_listener('nav_entity_add_user','entity_add_user');


function admin_add_staff(){
 return __action('nav_entity_add_user','staff');
}
add_listener('nav_admin_add_staff','admin_add_staff');

function admin_add_doctor(){
 return __action('nav_entity_add_user','doctor');
}
add_listener('nav_admin_add_doctor','admin_add_doctor');

function admin_add_patient(){
 return __action('nav_entity_add_user','patient');
}
add_listener('nav_admin_add_patient','admin_add_patient');



function admin_js_support($footer=''){
  start_buffer();
  include('template/admin_js.php');
 return $footer . get_buffer();
}
add_listener('footer','admin_js_support');


