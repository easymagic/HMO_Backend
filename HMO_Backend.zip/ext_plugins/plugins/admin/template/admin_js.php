<script type="text/javascript">
	(function($){

  
       $(function(){

         $('[data-value]').each(function(){
         	
         	var vl = $(this).data('value');
         	$(this).val(vl);

         });


       });


	})(jQuery);
</script>