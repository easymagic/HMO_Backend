<div class="col-xs-12">
	<h3>Companies / <?php echo ucfirst($type); ?> - List</h3>
</div>

<?php 
 // print_r($_SERVER);
?>

<div class="col-xs-12" align="right">
<!-- 	<a href="<?php echo base_url(); ?>admin/add_user" class="btn btn-primary"> + Add User</a>
 --></div>

<div class="col-xs-12">
	<?php 
      __filter('log_message');
	?>
</div>


<div class="col-xs-12">
	<table class="table">
		<tr>
         <th>
            Name
         </th>         
			<th>
				E-mail
			</th>
			<th>
				Phone
			</th>
		</tr>
		<?php 
         foreach ($item as $k=>$v){

         	?>
            
            <tr>

               <td>
                  <?php echo $v->name; ?>
               </td>

            	<td>
            		<?php echo $v->email; ?>
            	</td>


            	<td>
            		<?php echo $v->phone; ?>
            	</td>





            	<td>

            		<a href="<?php echo base_url(); ?>company/edit/<?php echo $v->id; ?>" class="btn btn-success">Edit</a>

                  <a href="<?php echo base_url(); ?>admin/staff/<?php echo $v->id; ?>" class="btn btn-info">View Staffs</a>


            	</td>
            </tr>

         	<?php 

         }
		?>
	</table>
</div>