<?php 

 //erp plugin php script
 require_once("erp_usecases.php"); 
 

 function erp_get_config($entity,$args){
  
  $config = array();
  
  $config['create_link'] = base_url() . 'erp/create/' . $entity . '/';
  $config['edit_link'] = base_url() . 'erp/edit/' . $entity . '/';
  $config['list_link'] = base_url() . 'erp/list/' . $entity . '/';
  $config['info_link'] = base_url() . 'erp/info/' . $entity . '/';

  $config['create_action'] = base_url() . 'actions/launch/erp/create/' . $entity . '/';
  $config['update_action'] = base_url() . 'actions/launch/erp/update/' . $entity . '/';
  $config['delete_action'] = base_url() . 'actions/launch/erp/delete/' . $entity . '/';

  foreach ($args as $k=>$v){//prepare the argument key-list
    $config['arg' . $k] = $v;
  }

  return $config;

 }
 add_listener('erp_get_config','erp_get_config');


 function erp_create($entity=''){
   
   save_history();

   $erp_config = __filter('erp_get_config',$entity,func_get_args());

   start_buffer();
   $fields = __action($entity . '_get_form_fields',array());
   include('template/create.php');
   return __filter('nav_admin_panel',get_buffer());
 }
 add_listener('nav_erp_create','erp_create');



 function erp_edit($entity='',$id=''){
   
   save_history();

   $erp_config = __filter('erp_get_config',$entity,func_get_args());

   start_buffer();
   
   $data = __action("entity_get_where",$entity,array("id"=>$id));
   if (count($data) > 0){
    $data = $data[0]; 
    
    include('template/edit.php'); 
   }else{
   	echo __filter("no_field_data","No Field Data!");
   }
   
   return __filter('nav_admin_panel',get_buffer());
 }
 add_listener('nav_erp_edit','erp_edit');


 function erp_info($entity='',$id=''){
   
   // save_history();

   $erp_config = __filter('erp_get_config',$entity,func_get_args());

   start_buffer();
   
   $data = __action("entity_get_where",$entity,array("id"=>$id));
   if (count($data) > 0){
    $data = $data[0]; 
    
    include('template/info.php'); 
   }else{
    echo __filter("no_field_data","No Field Data!");
   }
   
   return __filter('nav_admin_panel',get_buffer());
 }
 add_listener('nav_erp_info','erp_info');



 function erp_list($entity=''){
   
   save_history();

   $erp_config = __filter('erp_get_config',$entity,func_get_args());

   start_buffer();
   
   
   //user filter hooks
   __action($entity . '_filter');

   $data = __action("entity_get",$entity);
   if (count($data) > 0){
    // $data = $data[0]; 
    include('template/list.php'); 
   }else{
   	echo __filter("no_field_data","No Row Data!");
   }
   
   return __filter('nav_admin_panel',get_buffer());
 }
 add_listener('nav_erp_list','erp_list');



