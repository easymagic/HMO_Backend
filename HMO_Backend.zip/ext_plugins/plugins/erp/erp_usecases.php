<?php 

 // erp usecases

 //for create
 function uc_erp_create($entity=''){
  if (empty(request($entity)))request($entity,array()); //always use post-data array	
  $error = __action($entity . '_before_create',false);
  if (!$error){
    $id = __action("entity_create",$entity,request($entity));
    log_success(__action($entity . '_create_success','Record created successfully.'));
    $error = __action($entity . '_after_create',$id);
  }else{
  	log_error(__action($entity . '_create_error','Something went wrong!'));
  }
 }
 add_listener('uc_erp_create','uc_erp_create');



  //for update
 function uc_erp_update($entity='',$id){
  if (empty(request($entity)))request($entity,array()); //always use post-data array	
  $error = __action($entity . '_before_update',false);
  if (!$error){
  	__action('entity_where','id',$id);
    __action("entity_update",$entity,request($entity));
    log_success(__action($entity . '_update_success','Record updated successfully.'));
    $error = __action($entity . '_after_update',$id);
  }else{
  	log_error(__action($entity . '_update_error','Something went wrong!'));
  }
 }
 add_listener('uc_erp_update','uc_erp_update');




 //for delete
 function uc_erp_delete($entity='',$id=''){
  $error = __action($entity . '_before_delete',false);
  if (!$error){
  	__action('entity_where','id',$id);
    __action("entity_delete",$entity);
    log_success(__action($entity . '_delete_success','Record removed successfully.'));
    $error = __action($entity . '_after_delete',$id);
  }else{
  	log_error(__action($entity . '_delete_error','Something went wrong!'));
  }
 }
 add_listener('uc_erp_delete','uc_erp_delete');

