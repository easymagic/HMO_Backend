<form action="<?php echo $erp_config['create_action']; ?>" method="post">

<div class="col-xs-12">
	

 <div class="col-xs-12">
 	<h3>
 	  <?php echo __filter($entity . '_create_title','Create ' . $entity,$erp_config); ?>
 	</h3>
 </div>	

 <div class="col-xs-12" align="right">
<?php 
 echo __filter($entity . '_back_link','back_link',array(),$erp_config);
?>
 </div>


 <div class="col-xs-12">
 	<?php 
     echo __filter('log_message');
 	?>
 </div>


<!-- form body start -->
<?php 
 echo __filter($entity . '_form','form_view',array(),$erp_config);
?>
<!-- form body stop -->

 
 <div class="col-xs-12" style="margin-top: 11px;margin-bottom: 11px;">
 	<input type="submit" class="btn btn-success" value="<?php echo __filter($entity . '_create_button_label','Create',$erp_config); ?>">
 </div>

</div>	


 
</form>
