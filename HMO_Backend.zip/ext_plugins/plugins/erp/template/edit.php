<form action="<?php echo $erp_config['update_action'] . $id; ?>" method="post">

<div class="col-xs-12">
	

 <div class="col-xs-12">
 	<h3><?php echo __filter($entity . '_edit_title','Edit ' . $entity,$erp_config); ?></h3>
 </div>

 <div class="col-xs-12" align="right">
<?php 
 echo __filter($entity . '_back_link','back_link',$data,$erp_config);
?>
 </div>



 <div class="col-xs-12">
 	<?php 
     echo __filter('log_message');
 	?>
 </div>


<!-- form body start -->
<?php 
 echo __filter($entity . '_form','form_view',$data,$erp_config);
?>
<!-- form body stop -->

 
 <div class="col-xs-12" style="margin-top: 11px;margin-bottom: 11px;">
 	<input type="submit" class="btn btn-success" value="<?php echo __filter($entity . '_update_button_label','Update',$erp_config); ?>">
 </div>

</div>	


 
</form>