<div class="col-xs-12">
	

 <div class="col-xs-12">
 	<h3><?php echo __filter($entity . '_info_title',$entity . ' Info.',$erp_config); ?></h3>
 </div>	

 <div class="col-xs-12" align="right">
<?php 
 echo __filter($entity . '_back_link','back_link',$data,$erp_config);
?>
 </div>



<!-- form body start -->
<?php 
 echo __filter($entity . '_form','form_view',$data,$erp_config);
?>
<!-- form body stop -->



</div>


