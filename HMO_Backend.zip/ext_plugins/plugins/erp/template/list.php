<div class="col-xs-12">
	

	<div class="col-xs-12">
		<h3><?php echo __filter($entity . '_list_title','Manage ' . $entity,$erp_config); ?></h3>
	</div>

 <div class="col-xs-12">
 	<?php 
     echo __filter('log_message');
 	?>
 </div>


	<div class="col-xs-12" align="right">
		<?php 
          echo __filter($entity . '_table_tools','table_tools',$erp_config);
		?>
	</div>


	<div class="col-xs-12">
		<?php echo __filter($entity . '_filter_view','filter-view',$erp_config); ?>
	</div>


    <div class="col-xs-12" style="margin-top: 11px;">
<?php 

 echo __filter($entity . '_table','entity_table',$data,$erp_config);


?>
    </div>

   
    <div class="col-xs-12" style="margin-top: 11px;">
    	<?php 
         echo __filter($entity . '_pagination');
    	?>
    </div>



</div>

<script type="text/javascript">
	(function($){
		$(function(){
			$('.confirm').each(function(){
				$(this).on('click',function(){
					return confirm("Do you want to confirm this operation?");
				});
			});
		});
	})(jQuery);
</script>