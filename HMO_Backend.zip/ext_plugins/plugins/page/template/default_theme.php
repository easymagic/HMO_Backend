<style type="text/css">
	
	.nav-pils{
    padding: 4px;
    padding-top: 32px;
    /* background-color: blue; */
    /* color: #fff; */
    font-size: 20px;
    border-bottom: 4px solid #100a82;
        }


    .v-content{
      /*font-size: 20px;*/
      /*font-size: 20px;*/
      min-height: 84vh;

    }

    .v-footer{
      background-color: #100a82;
      color: #fff;
    }

</style>

<!-- <div class="col-xs-12">
	<div class="col-xs-12 col-md-12 nav-pils">
		<?php echo __filter('admin_title','Unnamed'); ?> 
	</div>
</div>
 -->

<!-- <div class="v-content col-xs-12"> -->

  <?php echo $content; ?>
    

<!-- </div> -->

<!-- <div class="col-xs-12">
  <div class="v-footer col-xs-12" align="right"><small>Powered by <?php echo __filter('powered_by','...who...'); ?></small></div>
</div>
 -->

