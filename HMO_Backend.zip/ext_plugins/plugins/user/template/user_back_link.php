<?php 
 if (isset($data->id) && $data->id != $user_id){ //for edit and info.
?>
<a href="<?php echo $config['list_link'] . $data->type; ?>" class="btn btn-primary">Back</a>
<?php 
 }else if (empty($data)){ //for create
?>
<a href="<?php echo $config['list_link'] . $config['arg1']; ?>" class="btn btn-primary">Back</a>
<?php  	
 }
?>