<?php 
 // if ($data->id != $user_id){
if (isset($config['arg0'])){
  // echo $config['arg1'];
}
?>
<a href="<?php echo $config['create_link'] . $config['arg1']; ?>" class="btn btn-success">+ Add User</a>
<?php 
 // }
?>